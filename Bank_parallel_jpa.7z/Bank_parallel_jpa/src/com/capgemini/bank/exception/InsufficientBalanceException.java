package com.capgemini.bank.exception;

public class InsufficientBalanceException extends Exception {

}
