package com.capgemini.bank.exception;

public class AccountDoesNotExist extends Exception {
	
}
